package com.setup;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utils.ConfigReader;
import com.utils.ExtentManager;
import com.utils.ScreenshotUtil;

public class Hooks extends SetupDriver {

	public static ExtentReports extent;

	@BeforeMethod
	public void setup() throws Exception {

		ConfigReader config =
				new ConfigReader();

		launchBrowser(
				config.getBrowser());

		extent = ExtentManager.getReport();
	}

	@AfterMethod
	public void tearDown(ITestResult result) {

		ExtentTest test =
				extent.createTest(
						result.getMethod().getMethodName());

		if(result.getStatus()
				== ITestResult.FAILURE) {

			String fileName =
					result.getMethod().getMethodName();

			Object[] parameters =
					result.getParameters();

			if(parameters.length > 0) {

				fileName =
						fileName
						+ "_"
						+ parameters[0].toString();
			}

			fileName =
					fileName
					+ "_"
					+ System.currentTimeMillis();

			String screenshotPath =
					ScreenshotUtil.captureScreenshot(
							driver,
							fileName);

			test.fail(
					result.getThrowable());

			try {

				test.addScreenCaptureFromPath(
						screenshotPath);

			} catch(Exception e) {

				e.printStackTrace();
			}

		}
		else if(result.getStatus()
				== ITestResult.SUCCESS) {

			test.pass("Test Passed");
		}
		else {

			test.skip("Test Skipped");
		}

		extent.flush();

		closeBrowser();
	}
}