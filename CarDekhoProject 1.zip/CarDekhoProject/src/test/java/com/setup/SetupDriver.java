package com.setup;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetupDriver {

	public static WebDriver driver;

	public void launchBrowser(String browser)
			throws Exception {

		if(browser.equalsIgnoreCase("chrome")) {

			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}

		else if(browser.equalsIgnoreCase("edge")) {

			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}

		else {

			throw new Exception(
					"Invalid Browser : "
							+ browser);
		}

		driver.manage().window().maximize();

		driver.manage().timeouts()
		.implicitlyWait(
				Duration.ofSeconds(10));

		driver.get("https://www.cardekho.com");
	}

	public void closeBrowser() {

		if(driver != null) {
			driver.quit();
		}
	}
}