package com.dataprovider;

import org.testng.annotations.DataProvider;

public class FilterDataProvider {

	@DataProvider(name = "budgetData")
	public Object[][] budgetData() {

		return new Object[][] {
			{"5 - 10 Lakh"},
			{"10 - 15 Lakh"}
		};
	}

	@DataProvider(name = "brandData")
	public Object[][] brandData() {

		return new Object[][] {
			{"Maruti Suzuki"},
			{"Hyundai"},
			{"Tata"},
			{"Honda"}
		};
	}

	@DataProvider(name = "multipleFilterData")
	public Object[][] multipleFilterData() {

		return new Object[][] {
			{"5 - 10 Lakh", "Maruti Suzuki"},
		};
	}

	@DataProvider(name = "irrelevantBrandData")
	public Object[][] irrelevantBrandData() {

		return new Object[][] {
			{"Hyundai", "Maruti Suzuki"},
			{"Tata", "Hyundai"}
		};
	}

	@DataProvider(name = "clearFilterData")
	public Object[][] clearFilterData() {

		return new Object[][] {
			{"Maruti Suzuki"},
			{"Hyundai"}
		};
	}

	@DataProvider(name = "resultCountData")
	public Object[][] resultCountData() {

		return new Object[][] {
			{"Maruti Suzuki"},
			{"Hyundai"}
		};
	}
}