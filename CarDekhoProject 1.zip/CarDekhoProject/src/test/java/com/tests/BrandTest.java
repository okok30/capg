package com.tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.dataprovider.TestDataProvider2;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrandTest {

    @Test(dataProvider = "filterData",
            dataProviderClass = TestDataProvider2.class)
    public void verifyFilters(String brand, String model)
            throws Exception {

        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();

        WebDriverWait wait =
                new WebDriverWait(
                        driver,
                        Duration.ofSeconds(10));

        try {

            driver.manage().window().maximize();

            driver.get("https://www.cardekho.com/newcars");

            // Click By Model
            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.cssSelector(
                                    "li[title='By Model']")))
                .click();

            // Select Brand
            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.id("bmvBrand")))
                .click();

            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                    "//li[contains(text(),'"
                                            + brand + "')]")))
                .click();

            // Select Model
            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.id("bmvModel")))
                .click();

            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                    "//li[contains(text(),'"
                                            + model + "')]")))
                .click();

            // Click Search
            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                    "(//button[@name='go'])[2]")))
                .click();

            Thread.sleep(1000);
            // Verify page heading
            WebElement carHeading =
                    wait.until(
                            ExpectedConditions
                                    .visibilityOfElementLocated(
                                            By.tagName("h1")));

            String actualCarName =
                    carHeading.getText();

            System.out.println(
                    "Actual Car Name : "
                            + actualCarName);

            Assert.assertTrue(
                    actualCarName
                            .toLowerCase()
                            .contains(
                                    model.toLowerCase()),
                    "Expected Model is not displayed");

            System.out.println(
                    "PASS : "
                            + brand
                            + " - "
                            + model);
        }

        finally {

            driver.navigate().back();
            driver.navigate().refresh();
            driver.quit();
        }
    }
    @Test
    public void verifySearchWithoutSelection()
            throws Exception {

        WebDriverManager.chromedriver().setup();

        WebDriver driver =
                new ChromeDriver();

        WebDriverWait wait =
                new WebDriverWait(
                        driver,
                        Duration.ofSeconds(10));

        try {

            driver.manage().window().maximize();

            driver.get("https://www.cardekho.com/newcars");

            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.cssSelector(
                                    "li[title='By Model']")))
                .click();

            // Click Search directly
            wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.xpath(
                                    "(//button[@name='go'])[2]")))
                .click();

            // Check validation text
            WebElement validation =wait.until(ExpectedConditions.visibilityOfElementLocated(
                                            By.xpath(
                                                    "//*[contains(text(),'Please')]")));

            String actualMessage =
                    validation.getText();

            System.out.println(
                    "Validation Message : "
                            + actualMessage);
            
            Assert.assertTrue(
                    actualMessage.length() > 0,
                    "Validation message not displayed");
            
            
        }

        finally {

            driver.quit();
        }
    }
}